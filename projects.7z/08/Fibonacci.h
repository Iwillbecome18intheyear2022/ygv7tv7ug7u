(FIB)
//short fibIndex(short *begin, short *end) {

  // define args

  // define locals

  // for(short *i=begin+1; i < end; i++) {

    // while i < end

    // sum = *(i-1) + *i ;

    // *i = *i++

    // *(i+1) = sum ;

  // }

  // return sum ;

// }
